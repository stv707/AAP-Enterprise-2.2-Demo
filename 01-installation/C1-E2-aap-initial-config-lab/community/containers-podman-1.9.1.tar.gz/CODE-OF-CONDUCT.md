## The Podman Ansible Collections Project Community Code of Conduct

The Podman Ansible Collections project follows the [Containers Community Code of Conduct](https://github.com/containers/common/blob/master/CODE-OF-CONDUCT.md).
